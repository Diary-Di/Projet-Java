import org.jfree.chart.*;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import java.awt.event.ActionEvent;
import java.awt.event.AWTEventListener;
import java.sql.*;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import BoutonTableau.cell.TableActionCellRenderer;
import BoutonTableau.cell.TableActionCellEditor;
import BoutonTableau.cell.TableActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author Diarinandrasana
 */
public class AccueilPage extends javax.swing.JFrame {

    /**
     * Creates new form AccueilPage
     */
    public AccueilPage() {
        initComponents();
        Connect();
        FetchMedicament();
        FetchEntree();
        FetchAchat();
        //appelFonction();
        //Map<String, Double> data = fetchdata();
        //JFreeChart barChart = createChart(data);
        //displayChart(barChart);
        
        
        TableActionEvent event=new TableActionEvent() {
            @Override
            public void onEdit(int row) {
                System.out.println("Edit row:"+row);// Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
                // Récupérer les données de la ligne courante
                String[] rowData = new String[tableMedicament.getColumnCount()];
            
                if (tableMedicament.isRowSelected(row)) {
                    for (int i = 0; i < tableMedicament.getColumnCount(); i++) {
                        rowData[i] = tableMedicament.getValueAt(row, i).toString();
                    }
                    showUpdateMedoc(rowData);
                } else if (tableEntree.isRowSelected(row)){
                    for (int i = 0; i < tableEntree.getColumnCount(); i++) {
                        rowData[i] = tableEntree.getValueAt(row, i).toString();
                    }
                    showUpdateEntree(rowData);
                } else if (tableAchat.isRowSelected(row)) {
                    System.out.println(tableAchat.getColumnCount());
                     for (int i = 0; i < rowData.length; i++) {
                        rowData[i] = tableAchat.getValueAt(row, i).toString();
                         System.out.println(rowData[i]);
                    }
                    showUpdateAchat(rowData);
                } else {
                    System.out.println("Aucune table selectionnee ou ligne invalide");
                }
        
            }
            
            private String[] getRowData(int row) {
                // Récupérer les données de la ligne courante du tableau
                // Retourner les données sous forme de tableau de chaînes
                return new String[]{/* données de la ligne courante */};
    }

            @Override
            public void onDelete(int row) {
                System.out.println("delete row:"+row); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            
                String numeroMedoc = "numMedoc";
                String numeroEntree = "numEntree";
                String numeroAchat = "numAchat";
                
                String idMedoc = null;
                String idEntree = null;
                String idAchat = null;
                
                if (tableMedicament.isRowSelected(row)) {                   
                    idMedoc = tableMedicament.getValueAt(row, 0).toString();
                    SupprimerDonnees("medicament", idMedoc, numeroMedoc);
                    removeRowFromTable(tableMedicament, row);
                    JOptionPane.showMessageDialog(null, "Ligne supprimee avec succes !");
                    FetchMedicament();
                    FetchEntree();
                    FetchAchat();
                    
                    //mettre a jour l'histogramme
                    Map<String, Double> newData = fetchdata();
                    JFreeChart newChart = createChart(newData);
                    displayChart(newChart);
                    
                } else if (tableEntree.isRowSelected(row)){
                    idEntree = tableEntree.getValueAt(row, 0).toString();
                    idMedoc = tableEntree.getValueAt(row, 1).toString();
                    logique(idEntree, idMedoc);
                    SupprimerDonnees("entree", idEntree, numeroEntree);
                    removeRowFromTable(tableEntree, row);
                    JOptionPane.showMessageDialog(null, "Ligne supprimee avec succes !");
                    FetchEntree();
                    FetchMedicament();
                    
                    //mettre a jour l'histogramme
                    Map<String, Double> newData = fetchdata();
                    JFreeChart newChart = createChart(newData);
                    displayChart(newChart);
                    
                } else if (tableAchat.isRowSelected(row)){
                    idAchat = tableAchat.getValueAt(row, 0).toString();
                    SupprimerDonnees("achat", idAchat, numeroAchat);
                    removeRowFromTable(tableAchat, row);
                    JOptionPane.showMessageDialog(null, "Ligne supprimee avec succes !");
                    FetchAchat();
                    FetchMedicament();
                    
                    //mettre a jour l'histogramme
                    Map<String, Double> newData = fetchdata();
                    JFreeChart newChart = createChart(newData);
                    displayChart(newChart);
                }
                
            }
        };
        tableMedicament.getColumnModel().getColumn(4).setCellRenderer(new TableActionCellRenderer());
        tableMedicament.getColumnModel().getColumn(4).setCellEditor(new TableActionCellEditor(event));
        tableEntree.getColumnModel().getColumn(4).setCellRenderer(new TableActionCellRenderer());
        tableEntree.getColumnModel().getColumn(4).setCellEditor(new TableActionCellEditor(event));
        tableAchat.getColumnModel().getColumn(5).setCellRenderer(new TableActionCellRenderer());
        tableAchat.getColumnModel().getColumn(5).setCellEditor(new TableActionCellEditor(event));
    }
    
    Connection con;
    PreparedStatement pst;
    ResultSet rs;
    
    private void Connect(){
        
        String sqlusername = "postgres";
        String sqlpassword = "QWERTY#2K24";
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Medicament.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/gestion_pharmacie", sqlusername, sqlpassword);
        } catch (SQLException ex) {
            Logger.getLogger(Medicament.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }
    
    public void FetchMedicament(){
        try {
            int q;
            pst = con.prepareStatement("SELECT * FROM medicament");
            rs = pst.executeQuery();
            ResultSetMetaData rss = rs.getMetaData();
            q = rss.getColumnCount(); 
            
            DefaultTableModel df = (DefaultTableModel)tableMedicament.getModel();
            df.setRowCount(0);
            while(rs.next()){
                Vector v2 = new Vector();
                for(int a = 0; a <= q; a++){
                    v2.add(rs.getString("numMedoc"));
                    v2.add(rs.getString("Design"));
                    v2.add(rs.getInt("prix_unitaire"));
                    v2.add(rs.getInt("stock"));
                }
                df.addRow(v2);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(MedicamentDonnee.class.getName()).log(Level.SEVERE, null, ex);
        }
        pageMedicament.revalidate();
        pageMedicament.repaint();
    }
    
     public void FetchEntree(){
        try {
            int q;
            pst = con.prepareStatement("SELECT * FROM entree");
            rs = pst.executeQuery();
            ResultSetMetaData rss = rs.getMetaData();
            q = rss.getColumnCount(); 
            
            DefaultTableModel df = (DefaultTableModel)tableEntree.getModel();
            df.setRowCount(0);
            while(rs.next()){
                Vector v2 = new Vector();
                for(int a = 0; a <= q; a++){
                    v2.add(rs.getString("numEntree"));
                    v2.add(rs.getString("numMedoc"));
                    v2.add(rs.getInt("stockEntree"));
                    v2.add(rs.getDate("dateEntree"));
                }
                df.addRow(v2);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(EntreeDonnees.class.getName()).log(Level.SEVERE, null, ex);
        }
        pageEntree.revalidate();
        pageEntree.repaint();
    }
     
     public void FetchAchat(){
        try {
            int q;
            pst = con.prepareStatement("SELECT * FROM achat");
            rs = pst.executeQuery();
            ResultSetMetaData rss = rs.getMetaData();
            q = rss.getColumnCount(); 
            
            DefaultTableModel df = (DefaultTableModel)tableAchat.getModel();
            df.setRowCount(0);
            while(rs.next()){
                Vector v2 = new Vector();
                for(int a = 0; a <= q; a++){
                    v2.add(rs.getString("numAchat"));
                    v2.add(rs.getString("numMedoc"));
                    v2.add(rs.getString("nomClient"));
                    v2.add(rs.getInt("nbr"));
                    v2.add(rs.getDate("dateAchat"));
                }
                df.addRow(v2);
            }
            
            appelFonction();
            
        } catch (SQLException ex) {
            Logger.getLogger(MedicamentDonnee.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        pageHistogramme.revalidate();
        pageHistogramme.repaint();
        histogramme.revalidate();
        histogramme.repaint();
        pageAchat.revalidate();
        pageAchat.repaint();
    }
     
     
    //methode pour afficher le jdialog
    private void showUpdateMedoc(String[] rowData){
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                UpdateMedoc dialog = new UpdateMedoc(AccueilPage.this, true, rowData);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        dialog.setVisible(false);
                    }
                });
                dialog.setVisible(true);
            }
        });
    } 
    
     private void showUpdateEntree(String[] rowData){
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                UpdateEntree dialog = new UpdateEntree(AccueilPage.this, true, rowData);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        dialog.setVisible(false);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }
     
      private void showUpdateAchat(String[] rowData){
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                UpdateAchat dialog = new UpdateAchat(AccueilPage.this, true, rowData);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        dialog.setVisible(false);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }
     
    private void SupprimerDonnees(String nomTable, String identifiant, String idNom){
        
        String sql = "DELETE FROM " + nomTable + " WHERE " + idNom + " = ?";
        
        try (PreparedStatement pstmt = con.prepareStatement(sql)){
            
            pstmt.setString(1, identifiant);
            int affectedRows = pstmt.executeUpdate();
            
            if (affectedRows > 0) {
                System.out.println("Ligne supprimee avec succees");
            } else {
                System.out.println("Aucune Ligne avec identifiant " + identifiant +" dans la table" + nomTable);
            }
            
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        
    }
    
    //recuperer le stock courant de medicament a supprimer dans la table medicament
     private Integer recupererStockCourant(String numMedoc) throws SQLException{
        Integer stockCourant = null;
            
            PreparedStatement pstmt = con.prepareStatement("SELECT stock FROM medicament WHERE numMedoc = ?");
            pstmt.setString(1,numMedoc);
            ResultSet rst = pstmt.executeQuery();
            
             if (rst.next()) {
                 stockCourant = rst.getInt("stock");
             } else {
                 System.out.println("Aucun medicament trouve avec cet Id");
             }
            
            rst.close();
            pstmt.close();

            return stockCourant;
    }
    
    //recupere les stock de medicament a supprimer dans la table entree
    private Integer recupererStockSuppression(String identifiant){
        
        Integer stockSuppr = null;
        String sql = "SELECT stockEntree FROM entree WHERE numEntree = ?";
        try (PreparedStatement pstmt = con.prepareStatement(sql)){
            pstmt.setString(1, identifiant);
            ResultSet rst = pstmt.executeQuery();
            
            if (rst.next()) {
                String stockSupprimer = rst.getString("stockEntree");
                stockSuppr = Integer.valueOf(stockSupprimer);
            }
        } catch (Exception e) {
            System.out.println("aucune entree correspondant a l'identifiant" + identifiant);
        }
        return stockSuppr;
    }
    
    //mise a jour du nombre de stock dans la table medicament
    public void ajouterStock(String id, int newStock) throws SQLException{
        PreparedStatement pstmt = con.prepareStatement("UPDATE medicament SET stock = ? WHERE numMedoc = ?");
        pstmt.setInt(1, newStock);
        pstmt.setString(2, id);
        pstmt.executeUpdate();
        pstmt.close();
    }
    
    //logique de la recuperation et remettre le stock a sa place
    private void logique(String identifiant, String numMedoc){
        try {
            Integer stockCourant = recupererStockCourant(numMedoc);
            Integer stockSuppr = recupererStockSuppression(identifiant);
            
             if (stockCourant != null| stockSuppr != null) {
                int newStock = stockCourant - stockSuppr;
                ajouterStock(numMedoc, newStock);
            }
        } catch (SQLException ex) {
            Logger.getLogger(AccueilPage.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void removeRowFromTable(JTable nomTable, int row){
        if (nomTable.isEditing()) {
            nomTable.getCellEditor().stopCellEditing();
        }
        
        DefaultTableModel model = (DefaultTableModel) nomTable.getModel();
        model.removeRow(row);
}
     
    //afficher les medicaments en rupture de stock
     public void Rupturestock(){
         try {
            int q;
            pst = con.prepareStatement("SELECT * FROM medicament WHERE stock < 5");
            rs = pst.executeQuery();
            ResultSetMetaData rss = rs.getMetaData();
            q = rss.getColumnCount(); 
            
            DefaultTableModel df = (DefaultTableModel)tableRuptureStock.getModel();
            df.setRowCount(0);
            while(rs.next()){
                Vector v2 = new Vector();
                for(int a = 0; a <= q; a++){
                    v2.add(rs.getString("numMedoc"));
                    v2.add(rs.getString("Design"));
                    v2.add(rs.getInt("stock"));
                }
                df.addRow(v2);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(AccueilPage.class.getName()).log(Level.SEVERE, null, ex);
        } 
     }
     
     //afficher les 5 medicaments les plus vendus 
     public void medocPlusVendus(){
     try {
            int q;
            pst = con.prepareStatement("SELECT a.numMedoc, m.Design, SUM(a.nbr) AS quantite_vendue FROM achat a JOIN medicament m ON a.numMedoc = m.numMedoc GROUP BY a.numMedoc, m.Design ORDER BY quantite_vendue DESC LIMIT 5");
            rs = pst.executeQuery();
            ResultSetMetaData rss = rs.getMetaData();
            q = rss.getColumnCount(); 
            
            DefaultTableModel df = (DefaultTableModel)tablePlusVendu.getModel();
            df.setRowCount(0);
            while(rs.next()){
                Vector v2 = new Vector();
                for(int a = 0; a <= q; a++){
                    v2.add(rs.getString("numMedoc"));
                    v2.add(rs.getString("Design"));
                    //v2.add(rs.getInt("nbr"));
                }
                df.addRow(v2);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(AccueilPage.class.getName()).log(Level.SEVERE, null, ex);
        } 
     }
     
     public Map<String, Double> fetchdata() {
        Map<String, Double> data = new HashMap<>();
        String query = "WITH Recette_mensuelles AS ("
                + "                     SELECT"
                + "                          A.numAchat,"
                + "                          A.numMedoc,"
                + "                          A.nbr,"
                + "                          A.dateAchat,"
                + "                          M.prix_unitaire,"
                + "                         (A.nbr * M.prix_unitaire) AS total"
                + "                          FROM achat A"
                + "                          JOIN medicament M ON A.numMedoc = M.numMedoc "
                + "                          WHERE A.dateAchat >= DATE_TRUNC('month', NOW() - INTERVAL '5 months'))"
                + "                     SELECT"
                + "                          TO_CHAR(dateAchat, 'YYYY-MM') AS mois,"
                + "                         SUM(total) AS recette"
                + "                     FROM"
                + "                         Recette_mensuelles"
                + "                     GROUP BY"
                + "                         TO_CHAR(dateAchat, 'YYYY-MM')"
                + "                     ORDER BY"
                + "                         mois LIMIT 5";

        try (Statement stmt = con.createStatement();
             ResultSet rst = stmt.executeQuery(query)) {

            while (rst.next()) {
                String month = rst.getString("mois");
                double revenue = rst.getDouble("recette");
                data.put(month, revenue);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return data;
    }
     
     public JFreeChart createChart(Map<String, Double> data){
         DefaultCategoryDataset dataset = new DefaultCategoryDataset();
         
  for (Map.Entry<String, Double> entry : data.entrySet()) {
    dataset.addValue(entry.getValue(), "Recettes", entry.getKey());
         }
         
         JFreeChart barChart = ChartFactory.createBarChart(
                 "",
                 "Mois",
                 "Recette (en Ariary)",
                 dataset,
                 PlotOrientation.VERTICAL,
                 true, true, false);
         
        CategoryPlot plot = (CategoryPlot) barChart.getPlot();
        plot.setDomainAxis(new CategoryAxis("Mois"));
        plot.setRangeAxis(new NumberAxis("Recette (en Ariary)"));
        
        return barChart;
        
     }
     
     public void displayChart(JFreeChart chart) {
        histogramme.removeAll();  // Remove previous chart
        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new java.awt.Dimension(420, 320));
        histogramme.setLayout(new java.awt.BorderLayout());
        histogramme.add(chartPanel, java.awt.BorderLayout.CENTER);
        histogramme.validate();
     }
     
    public void appelFonction(){
        //FetchAchat();
        String recette = recupererRecette();
        recetteTotale.setText(recette +"Ariary");
        Rupturestock();
        medocPlusVendus();
        Map<String, Double> data = fetchdata();
            JFreeChart barChart = createChart(data);
            displayChart(barChart);
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        medicamentBouton = new javax.swing.JButton();
        entreeButton = new javax.swing.JButton();
        achatbouton = new javax.swing.JButton();
        histogramBouton = new javax.swing.JButton();
        rechercheChamp = new javax.swing.JTextField();
        rechercheBouton = new javax.swing.JButton();
        accueilBouton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        parentPanel = new javax.swing.JPanel();
        pageAccueil = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        pageMedicament = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableMedicament = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        boutonMedoc = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        pageEntree = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tableEntree = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        BoutonEntree = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        pageAchat = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tableAchat = new javax.swing.JTable();
        jLabel8 = new javax.swing.JLabel();
        BoutonAchat = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        pageHistogramme = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        tablePlusVendu = new javax.swing.JTable();
        jLabel14 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        tableRuptureStock = new javax.swing.JTable();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        recetteTotale = new javax.swing.JTextField();
        histogramme = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        pageRecherche = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tableRecherche = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(153, 0, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        medicamentBouton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/medicament.png"))); // NOI18N
        medicamentBouton.setContentAreaFilled(false);
        medicamentBouton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                medicamentBoutonActionPerformed(evt);
            }
        });
        jPanel1.add(medicamentBouton, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 0, -1, 32));

        entreeButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/depot.png"))); // NOI18N
        entreeButton.setContentAreaFilled(false);
        entreeButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                entreeButtonActionPerformed(evt);
            }
        });
        jPanel1.add(entreeButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 0, 35, 33));

        achatbouton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/acheter.png"))); // NOI18N
        achatbouton.setContentAreaFilled(false);
        achatbouton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                achatboutonActionPerformed(evt);
            }
        });
        jPanel1.add(achatbouton, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 0, 34, 30));

        histogramBouton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/histogram.png"))); // NOI18N
        histogramBouton.setContentAreaFilled(false);
        histogramBouton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                histogramBoutonActionPerformed(evt);
            }
        });
        jPanel1.add(histogramBouton, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 0, 32, 33));

        rechercheChamp.setBackground(new java.awt.Color(255, 255, 255));
        rechercheChamp.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        rechercheChamp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rechercheChampActionPerformed(evt);
            }
        });
        rechercheChamp.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                rechercheChampKeyReleased(evt);
            }
        });
        jPanel1.add(rechercheChamp, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 10, 232, 30));

        rechercheBouton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/recherche.png"))); // NOI18N
        rechercheBouton.setContentAreaFilled(false);
        rechercheBouton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rechercheBoutonActionPerformed(evt);
            }
        });
        jPanel1.add(rechercheBouton, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 10, 33, 30));

        accueilBouton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/accueil.png"))); // NOI18N
        accueilBouton.setContentAreaFilled(false);
        accueilBouton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                accueilBoutonActionPerformed(evt);
            }
        });
        jPanel1.add(accueilBouton, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, -1, 33));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setText("Accueil");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 30, -1, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setText("Medicament");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 30, -1, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setText("Entree");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 30, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setText("Achat");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 30, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setText("Statistiques");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 30, -1, -1));

        getContentPane().add(jPanel1, java.awt.BorderLayout.PAGE_START);

        parentPanel.setLayout(new java.awt.CardLayout());

        pageAccueil.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/background.png"))); // NOI18N
        pageAccueil.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 920, 550));

        parentPanel.add(pageAccueil, "card6");

        pageMedicament.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tableMedicament.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "N° medicament", "Designation", "Prix unitaire", "Stock disponible", "Actions"
            }
        ));
        tableMedicament.setRowHeight(35);
        tableMedicament.setShowGrid(false);
        jScrollPane1.setViewportView(tableMedicament);
        if (tableMedicament.getColumnModel().getColumnCount() > 0) {
            tableMedicament.getColumnModel().getColumn(4).setPreferredWidth(20);
        }

        pageMedicament.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 920, 440));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel6.setText("LISTE DES MEDICAMENTS");
        pageMedicament.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 10, -1, 70));

        boutonMedoc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Ajouter.png"))); // NOI18N
        boutonMedoc.setContentAreaFilled(false);
        boutonMedoc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boutonMedocActionPerformed(evt);
            }
        });
        pageMedicament.add(boutonMedoc, new org.netbeans.lib.awtextra.AbsoluteConstraints(828, 6, 50, -1));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel10.setText("Nouveau ajout");
        pageMedicament.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 60, -1, -1));

        parentPanel.add(pageMedicament, "card5");

        pageEntree.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tableEntree.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "N° medicament", "N° medicament", "Stock entree", "Date de l'entree", "Actions"
            }
        ));
        tableEntree.setRowHeight(35);
        jScrollPane2.setViewportView(tableEntree);
        if (tableEntree.getColumnModel().getColumnCount() > 0) {
            tableEntree.getColumnModel().getColumn(4).setPreferredWidth(20);
        }

        pageEntree.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 920, 451));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel7.setText("LISTE DES ENTREES");
        pageEntree.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(296, 6, -1, 78));

        BoutonEntree.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Ajouter.png"))); // NOI18N
        BoutonEntree.setContentAreaFilled(false);
        BoutonEntree.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BoutonEntreeActionPerformed(evt);
            }
        });
        pageEntree.add(BoutonEntree, new org.netbeans.lib.awtextra.AbsoluteConstraints(828, 6, 50, -1));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel11.setText("Nouveau ajout");
        pageEntree.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 60, -1, -1));

        parentPanel.add(pageEntree, "card4");

        pageAchat.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tableAchat.setAutoCreateRowSorter(true);
        tableAchat.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "N° achat", "N° medicament", "Nom du Client", "Nombre de medicament", "Date de l'achat", "Actions"
            }
        ));
        tableAchat.setFocusCycleRoot(true);
        tableAchat.setRowHeight(35);
        tableAchat.setShowGrid(false);
        jScrollPane3.setViewportView(tableAchat);
        if (tableAchat.getColumnModel().getColumnCount() > 0) {
            tableAchat.getColumnModel().getColumn(2).setResizable(false);
            tableAchat.getColumnModel().getColumn(4).setResizable(false);
            tableAchat.getColumnModel().getColumn(4).setPreferredWidth(20);
            tableAchat.getColumnModel().getColumn(5).setPreferredWidth(20);
        }

        pageAchat.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 98, 920, 450));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel8.setText("LISTE DES ACHATS");
        pageAchat.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 10, -1, 80));

        BoutonAchat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Ajouter.png"))); // NOI18N
        BoutonAchat.setContentAreaFilled(false);
        BoutonAchat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BoutonAchatActionPerformed(evt);
            }
        });
        pageAchat.add(BoutonAchat, new org.netbeans.lib.awtextra.AbsoluteConstraints(828, 6, 50, -1));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel12.setText("Nouveau ajout");
        pageAchat.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 60, -1, -1));

        parentPanel.add(pageAchat, "card3");

        pageHistogramme.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel13.setText("STATISTIQUES DES VENTES ");
        pageHistogramme.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 10, -1, -1));

        tablePlusVendu.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "N° Medicament", "Designation"
            }
        ));
        tablePlusVendu.setRequestFocusEnabled(false);
        tablePlusVendu.setRowHeight(25);
        tablePlusVendu.setShowGrid(true);
        jScrollPane5.setViewportView(tablePlusVendu);

        pageHistogramme.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 420, 150));

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel14.setText("Recette total accumule par la pharmacie");
        pageHistogramme.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 440, 350, -1));

        tableRuptureStock.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "N° Medicament", "Designation", "Stock restant"
            }
        ));
        tableRuptureStock.setRowHeight(25);
        tableRuptureStock.setShowGrid(true);
        jScrollPane6.setViewportView(tableRuptureStock);

        pageHistogramme.add(jScrollPane6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 290, 420, 230));

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel15.setText("Hitsogramme des recettes des 5 derniers mois");
        pageHistogramme.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 70, 410, -1));

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel16.setText("Les medicaments en rupture de stock");
        pageHistogramme.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, 340, -1));

        recetteTotale.setEditable(false);
        recetteTotale.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        recetteTotale.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        pageHistogramme.add(recetteTotale, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 480, 280, 40));
        pageHistogramme.add(histogramme, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 100, 420, 320));

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel18.setText("Les 5 medicaments les plus vendus");
        pageHistogramme.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 300, -1));

        parentPanel.add(pageHistogramme, "card2");

        pageRecherche.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel9.setText("RESULTATS DE LA RECHERCHE");
        pageRecherche.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(213, 13, -1, -1));

        tableRecherche.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "N° medicament", "Designation", "Prix unitaire", "Stock disponible"
            }
        ));
        jScrollPane4.setViewportView(tableRecherche);
        if (tableRecherche.getColumnModel().getColumnCount() > 0) {
            tableRecherche.getColumnModel().getColumn(3).setPreferredWidth(20);
        }

        pageRecherche.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 73, 905, 443));

        parentPanel.add(pageRecherche, "card7");

        getContentPane().add(parentPanel, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void accueilBoutonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_accueilBoutonActionPerformed
        // TODO add your handling code here:
        parentPanel.removeAll();
        parentPanel.add(pageAccueil);
        parentPanel.repaint();
        parentPanel.revalidate();
        
    }//GEN-LAST:event_accueilBoutonActionPerformed

    private void medicamentBoutonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_medicamentBoutonActionPerformed
        // TODO add your handling code here:
        parentPanel.removeAll();
        parentPanel.add(pageMedicament);
        parentPanel.repaint();
        parentPanel.revalidate();
    }//GEN-LAST:event_medicamentBoutonActionPerformed

    private void entreeButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_entreeButtonActionPerformed
        // TODO add your handling code here:
        parentPanel.removeAll();
        parentPanel.add(pageEntree);
        parentPanel.repaint();
        parentPanel.revalidate();
    }//GEN-LAST:event_entreeButtonActionPerformed

    private void achatboutonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_achatboutonActionPerformed
        // TODO add your handling code here:
        parentPanel.removeAll();
        parentPanel.add(pageAchat);
        parentPanel.repaint();
        parentPanel.revalidate();
    }//GEN-LAST:event_achatboutonActionPerformed

    private void histogramBoutonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_histogramBoutonActionPerformed
        // TODO add your handling code here:
        
    histogramBouton.addActionListener(new ActionListener() {
  @Override
   public void actionPerformed(ActionEvent e) {
                Rupturestock();
                medocPlusVendus();
                Map<String, Double> newData = fetchdata();
                JFreeChart newChart = createChart(newData);
                displayChart(newChart);
            }
});
        parentPanel.removeAll();
        parentPanel.add(pageHistogramme);
        parentPanel.repaint();
        parentPanel.revalidate();
    }//GEN-LAST:event_histogramBoutonActionPerformed

    private void rechercheBoutonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rechercheBoutonActionPerformed
        // TODO add your handling code here:
        parentPanel.removeAll();
        parentPanel.add(pageRecherche);
        parentPanel.repaint();
        parentPanel.revalidate();
        
        try {
            String Designation = rechercheChamp.getText();
            
            int q;
            pst = con.prepareStatement("SELECT * FROM medicament WHERE Design ILIKE ?");
            pst.setString(1,"%"+Designation+"%");
            
             rs = pst.executeQuery();
            ResultSetMetaData rss = rs.getMetaData();
            q = rss.getColumnCount();
            
            DefaultTableModel df = (DefaultTableModel)tableRecherche.getModel();
            df.setRowCount(0);
            while(rs.next()){
                Vector v2 = new Vector();
                for(int a = 0; a <= q; a++){
                    v2.add(rs.getString("numMedoc"));
                    v2.add(rs.getString("Design"));
                    v2.add(rs.getInt("prix_unitaire"));
                    v2.add(rs.getInt("stock"));
                }
                df.addRow(v2);
            }
            
        } catch (Exception e) {
             Logger.getLogger(AccueilPage.class.getName()).log(Level.SEVERE, null, e);
        }
    }//GEN-LAST:event_rechercheBoutonActionPerformed

    private void boutonMedocActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boutonMedocActionPerformed
        // TODO add your handling code here:
        Medicament medicament = new Medicament(AccueilPage.this);
        medicament.setVisible(true);
    }//GEN-LAST:event_boutonMedocActionPerformed

    private void BoutonEntreeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BoutonEntreeActionPerformed
        // TODO add your handling code here:
        Entree entree = new Entree(AccueilPage.this);
        entree.setVisible(true);
    }//GEN-LAST:event_BoutonEntreeActionPerformed

    private void BoutonAchatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BoutonAchatActionPerformed
        // TODO add your handling code here:
        Achat achat = new Achat(AccueilPage.this);
        achat.setVisible(true);
    }//GEN-LAST:event_BoutonAchatActionPerformed

    private void rechercheChampKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_rechercheChampKeyReleased
        // TODO add your handling code here:

        String recherche = rechercheChamp.getText();
        
        if (recherche.isEmpty()) {
            parentPanel.removeAll();
            parentPanel.add(pageMedicament);
            parentPanel.repaint();
            parentPanel.revalidate();
        }else {
            parentPanel.removeAll();
            parentPanel.add(pageRecherche);
            parentPanel.repaint();
            parentPanel.revalidate();
        try {
            String Designation = rechercheChamp.getText();
            
            int q;
            pst = con.prepareStatement("SELECT * FROM medicament WHERE Design ILIKE ?");
            pst.setString(1,"%"+Designation+"%");
            
             rs = pst.executeQuery();
            ResultSetMetaData rss = rs.getMetaData();
            q = rss.getColumnCount();
            
            DefaultTableModel df = (DefaultTableModel)tableRecherche.getModel();
            df.setRowCount(0);
            while(rs.next()){
                Vector v2 = new Vector();
                for(int a = 0; a <= q; a++){
                    v2.add(rs.getString("numMedoc"));
                    v2.add(rs.getString("Design"));
                    v2.add(rs.getInt("prix_unitaire"));
                    v2.add(rs.getInt("stock"));
                }
                df.addRow(v2);
            }
            
        } catch (Exception e) {
             Logger.getLogger(AccueilPage.class.getName()).log(Level.SEVERE, null, e);
        }
        }
    }//GEN-LAST:event_rechercheChampKeyReleased

    public String recupererRecette(){
        int rTotal = 0;
        String recette = null;
        
        try {
            String sql = "SELECT SUM(m.prix_unitaire * a.nbr)AS recetteTotal FROM medicament m JOIN achat a ON a.numMedoc = m.numMedoc";
            PreparedStatement pstmt = con.prepareStatement(sql);
            try (ResultSet rst = pstmt.executeQuery()){
    
            if (rst.next()) {
                rTotal = rst.getInt("recetteTotal");
                recette = String.valueOf(rTotal);
                //recetteTotale.setText(recette);
            }else{
                System.out.println("erreur");
                }
            }
        } catch (SQLException e) {
            Logger.getLogger(AccueilPage.class.getName()).log(Level.SEVERE, null, e);
        }
       
        return recette;
    }
        
    
    private void rechercheChampActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rechercheChampActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rechercheChampActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AccueilPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AccueilPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AccueilPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AccueilPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AccueilPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BoutonAchat;
    private javax.swing.JButton BoutonEntree;
    private javax.swing.JButton accueilBouton;
    private javax.swing.JButton achatbouton;
    private javax.swing.JButton boutonMedoc;
    private javax.swing.JButton entreeButton;
    private javax.swing.JButton histogramBouton;
    private javax.swing.JPanel histogramme;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JButton medicamentBouton;
    private javax.swing.JPanel pageAccueil;
    private javax.swing.JPanel pageAchat;
    private javax.swing.JPanel pageEntree;
    private javax.swing.JPanel pageHistogramme;
    private javax.swing.JPanel pageMedicament;
    private javax.swing.JPanel pageRecherche;
    private javax.swing.JPanel parentPanel;
    private javax.swing.JTextField recetteTotale;
    private javax.swing.JButton rechercheBouton;
    private javax.swing.JTextField rechercheChamp;
    private javax.swing.JTable tableAchat;
    private javax.swing.JTable tableEntree;
    private javax.swing.JTable tableMedicament;
    private javax.swing.JTable tablePlusVendu;
    private javax.swing.JTable tableRecherche;
    private javax.swing.JTable tableRuptureStock;
    // End of variables declaration//GEN-END:variables
}
