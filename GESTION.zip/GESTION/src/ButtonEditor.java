/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Diarinandrasana
 */

import javax.swing.*;
import javax.swing.AbstractCellEditor;
import javax.swing.table.TableCellEditor;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ButtonEditor extends AbstractCellEditor implements TableCellEditor, ActionListener {
    private JButton button;
    private String label;
    private boolean isPushed;
    
    public ButtonEditor(JCheckBox checkBox){
        button = new JButton();
        button.setOpaque(true);
        button.addActionListener(this);
    }
    
    public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column){
        label = (value == null) ? "" : value.toString();
        button.setText(label);
        isPushed = true;
        return button;
    }
    
    public Object getCellEditorValue(){
        if (isPushed){
            //implementer la modification/suppresion
            System.out.println(label + ": Ouch!");
        }
        isPushed = false;
        return label;
    }
    
    public void actionPerformed(ActionEvent e) {
        fireEditingStopped();
    }
    
    public boolean stopCellEditing(){
        isPushed = false;
        return super.stopCellEditing();
    }
    
    protected void fireEditingStopped(){
        super.fireEditingStopped();
    }
    
    }

