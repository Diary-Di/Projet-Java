
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */

/**
 *
 * @author Diarinandrasana
 */
public class UpdateAchat extends javax.swing.JDialog {

    /**
     * Creates new form UpdateAchat
     * @param parent
     * @param modal
     * @param rowData
     */
    private AccueilPage accueilPage;
    public UpdateAchat(java.awt.Frame parent, boolean modal, String[] rowData) {
        super(parent, modal);
        this.accueilPage = (AccueilPage)parent;
        initComponents();
        setLocationRelativeTo(parent);
        Connect();
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        
       // achatDate.setDateFormatString("yyyy-MM-dd"); // Assurez-vous que le format de la date est correct
        //achatDate.getDateEditor().setEnabled(true); // Permet à l'utilisateur de modifier la date

        nAchat.setText(rowData[0]);
        nMedoc.setText(rowData[1]);
        noClient.setText(rowData[2]);
        nbMedoc.setText(rowData[3]);
        String dateFormat = "yyyy-MM-dd";
        
        try {
            // Convertir la chaîne en Date
            SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
            java.util.Date date = sdf.parse(rowData[4]);
            
            // Définir la date dans JDateChooser
            achatDate.setDate(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
    
    }
    
     Connection con;
    PreparedStatement pst;
    
    public void Connect(){
        
        String sqlusername = "postgres";
        String sqlpassword = "QWERTY#2K24";
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Medicament.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/gestion_pharmacie", sqlusername, sqlpassword);
        } catch (SQLException ex) {
            Logger.getLogger(Medicament.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
     public Integer recupererNombre(String id) throws SQLException{
        Integer nbCourant = null;
            
            PreparedStatement pst = con.prepareStatement("SELECT nbr FROM achat WHERE numAchat = ?");
            pst.setString(1,id);
            ResultSet rs = pst.executeQuery();
            
             if (rs.next()) {
                 nbCourant = rs.getInt("nbr");
             } else {
                 System.out.println("Aucun Achat trouve avec cet Id");
             }
            
            rs.close();
            pst.close();

            return nbCourant;
    }
     
    public Integer voirStockMedoc(String numMedoc) throws SQLException{
         Integer stockMedoc = null;
            
            PreparedStatement pst = con.prepareStatement("SELECT stock FROM medicament WHERE numMedoc = ?");
            pst.setString(1, numMedoc);
            ResultSet rs = pst.executeQuery();
            
             if (rs.next()) {
                 stockMedoc = rs.getInt("stock");
             } else {
                 System.out.println("Aucun medicament trouve avec cet Id");
             }
            
            rs.close();
            pst.close();

            return stockMedoc;
    }
    
    public void ajouterStock(String numMedoc, int newStock) throws SQLException{
        PreparedStatement pstmt = con.prepareStatement("UPDATE medicament SET stock = ? WHERE numMedoc = ?");
        pstmt.setInt(1, newStock);
        pstmt.setString(2, numMedoc);
        pstmt.executeUpdate();
        pstmt.close();
    }
    
    public void logique(){
        try {
            String id = nAchat.getText();
            String numMedoc = nMedoc.getText();
            String stockA = nbMedoc.getText();
            int nbModifier = Integer.parseInt(stockA);
            System.out.println(nbModifier);
            
            Integer stockMedoc = voirStockMedoc(numMedoc);
            Integer nbCourant = recupererNombre(id);
            
            System.out.println(stockMedoc);
            System.out.println(nbCourant);
            
            if (nbCourant != null |nbCourant < nbModifier) {
               int supNombre = nbModifier - nbCourant;
                System.out.println(supNombre);
               int newStock = stockMedoc - supNombre;
               System.out.println(newStock);
               ajouterStock(numMedoc, newStock);
            }else if (nbCourant != null |nbCourant > nbModifier) {
                int minStock = nbCourant - nbModifier;
                System.out.println(minStock);
                int newStock = stockMedoc + minStock;
                System.out.println(newStock);
                ajouterStock(numMedoc, newStock);  
            }
            
            
            /*if (stockCourant != null) {
                int newStock = stockIntro + stockCourant;
                ajouterStock(id, newStock);
            }*/
        } catch (NumberFormatException | SQLException e) {
            System.out.println("Entree de stock invalide; veuillez saisir un nombre");
            e.printStackTrace();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        nAchat = new javax.swing.JTextField();
        nMedoc = new javax.swing.JTextField();
        noClient = new javax.swing.JTextField();
        nbMedoc = new javax.swing.JTextField();
        achatDate = new com.toedter.calendar.JDateChooser();
        enregistrerBouton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(nAchat, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 100, 341, 38));
        getContentPane().add(nMedoc, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 170, 341, 38));
        getContentPane().add(noClient, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 240, 341, 38));
        getContentPane().add(nbMedoc, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 310, 341, 38));
        getContentPane().add(achatDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 380, 341, 38));

        enregistrerBouton.setBackground(new java.awt.Color(0, 153, 51));
        enregistrerBouton.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        enregistrerBouton.setText("ENREGISTRER");
        enregistrerBouton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                enregistrerBoutonActionPerformed(evt);
            }
        });
        getContentPane().add(enregistrerBouton, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 440, 341, 38));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Numero de l'achat");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 80, -1, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("Numero du medicament");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 150, -1, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Nom du client");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 220, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Nombre de medicament achete");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 290, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Date de l'achat");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 360, -1, -1));

        jLabel6.setFont(new java.awt.Font("Arial", 1, 48)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 0));
        jLabel6.setText("ACHAT");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 20, -1, -1));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Achat.png"))); // NOI18N
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 0, 97, 97));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/back.png"))); // NOI18N
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 480, 500));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void enregistrerBoutonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_enregistrerBoutonActionPerformed
        try {
             
            logique();
            
            String id = nAchat.getText();
            String numMedoc = nMedoc.getText();
            String nomClient = noClient.getText();
            String noStock = nbMedoc.getText();
            java.util.Date dateE = achatDate.getDate();

            int nombreStock = Integer.parseInt(noStock);
            
            java.sql.Date sqlDate = new java.sql.Date(dateE.getTime());

            pst = con.prepareStatement("UPDATE achat SET numMedoc = ?, nomClient = ?, nbr = ?, dateAchat = ? WHERE numAchat = ?");
            pst.setString(1,numMedoc);
            pst.setString(2, nomClient);
            pst.setInt(3,nombreStock);
            pst.setDate(4, (java.sql.Date) sqlDate);
            pst.setString(5,id);

            int k = pst.executeUpdate();
            
            
            if (k==1){
                accueilPage.FetchAchat();
                accueilPage.FetchMedicament();
                JOptionPane.showMessageDialog(this,"Modification enregistree avec succes");
                nAchat.setText("");
                noClient.setText("");
                nMedoc.setText("");
                nbMedoc.setText("");
                achatDate.setDate(null);
            }else{
                JOptionPane.showMessageDialog(this,"Erreur lors de la modification");
            }
        } catch (SQLException ex) {
            Logger.getLogger(Entree.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }//GEN-LAST:event_enregistrerBoutonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UpdateAchat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UpdateAchat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UpdateAchat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UpdateAchat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                String[] rowData = {};
                
                UpdateAchat dialog = new UpdateAchat(new javax.swing.JFrame(), true, rowData);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.toedter.calendar.JDateChooser achatDate;
    private javax.swing.JButton enregistrerBouton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JTextField nAchat;
    private javax.swing.JTextField nMedoc;
    private javax.swing.JTextField nbMedoc;
    private javax.swing.JTextField noClient;
    // End of variables declaration//GEN-END:variables
}
