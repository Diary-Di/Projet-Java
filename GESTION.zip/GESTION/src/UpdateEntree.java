
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */

/**
 *
 * @author Diarinandrasana
 */
public class UpdateEntree extends javax.swing.JDialog {

    /**
     * Creates new form UpdateEntree
     * @param parent
     * @param modal
     * @param rowData
     */
    private AccueilPage accueilPage;
    public UpdateEntree(java.awt.Frame parent, boolean modal, String[] rowData) {
        super(parent, modal);
        this.accueilPage = (AccueilPage) parent;
        initComponents();
         setLocationRelativeTo(parent);
        Connect();
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        
        nEntree.setText(rowData[0]);
        nMedoc.setText(rowData[1]);
        stockEntree.setText(rowData[2]);
        String dateFormat = "yyyy-MM-dd";
        
        try {
            // Convertir la chaîne en Date
            SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
            java.util.Date date = sdf.parse(rowData[3]);
            
            // Définir la date dans JDateChooser
            dateEntree.setDate(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
    
    }
    
    Connection con;
    PreparedStatement pst;
    
     public void Connect(){
        
        String sqlusername = "postgres";
        String sqlpassword = "QWERTY#2K24";
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Medicament.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/gestion_pharmacie", sqlusername, sqlpassword);
        } catch (SQLException ex) {
            Logger.getLogger(Medicament.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     
     public Integer recupererStock(String id) throws SQLException{
        Integer stockCourant = null;
            
            PreparedStatement pst = con.prepareStatement("SELECT stock FROM medicament WHERE numMedoc = ?");
            pst.setString(1,id);
            ResultSet rs = pst.executeQuery();
            
             if (rs.next()) {
                 stockCourant = rs.getInt("stock");
             } else {
                 System.out.println("Aucun medicament trouve avec cet Id");
             }
            
            rs.close();
            pst.close();

            return stockCourant;
    }
    
     public Integer voirStock(String numEntree) throws SQLException{
        Integer stockAncien = null;
            
            PreparedStatement pstmt = con.prepareStatement("SELECT stockEntree FROM entree WHERE numEntree = ?");
            pstmt.setString(1,numEntree);
            ResultSet rs = pstmt.executeQuery();
            
             if (rs.next()) {
                 stockAncien = rs.getInt("stockEntree");
             } else {
                 System.out.println("Aucun medicament trouve avec cet Id");
             }
            
            rs.close();
            pstmt.close();

            return stockAncien;
    
     }
    
    public void ajouterStock(String id, int newStock) throws SQLException{
        PreparedStatement pstmt = con.prepareStatement("UPDATE medicament SET stock = ? WHERE numMedoc = ?");
        pstmt.setInt(1, newStock);
        pstmt.setString(2, id);
        pstmt.executeUpdate();
        pstmt.close();
    }
    
    public void logique(){
        try {
            String numEntree = nEntree.getText();
            String id = nMedoc.getText();
            String stockE = stockEntree.getText();
            int stockSaisie = Integer.parseInt(stockE);
            
            Integer stockAncien = voirStock(numEntree);
            Integer stockCourant = recupererStock(id);
            
            if (stockCourant != null |stockAncien < stockSaisie) {
               int supStock = stockSaisie - stockAncien;
               int newStock = stockCourant + supStock;
               ajouterStock(id, newStock);
            }else if (stockCourant != null |stockAncien > stockSaisie) {
                int minStock = stockAncien - stockSaisie;
                int newStock = stockCourant - minStock;
                ajouterStock(id, newStock);
            }
            /*if (stockCourant != null) {
                int newStock = stockIntro + stockCourant;
                ajouterStock(id, newStock);
            }*/
        } catch (NumberFormatException | SQLException e) {
            System.out.println("Entree de stock invalide; veuillez saisir un nombre");
            e.printStackTrace();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        nEntree = new javax.swing.JTextField();
        nMedoc = new javax.swing.JTextField();
        stockEntree = new javax.swing.JTextField();
        enregistrerBouton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        dateEntree = new com.toedter.calendar.JDateChooser();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(nEntree, new org.netbeans.lib.awtextra.AbsoluteConstraints(69, 94, 343, 38));

        nMedoc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nMedocActionPerformed(evt);
            }
        });
        getContentPane().add(nMedoc, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 170, 343, 38));
        getContentPane().add(stockEntree, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 240, 343, 38));

        enregistrerBouton.setBackground(new java.awt.Color(0, 153, 51));
        enregistrerBouton.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        enregistrerBouton.setForeground(new java.awt.Color(0, 0, 0));
        enregistrerBouton.setText("ENREGISTRER");
        enregistrerBouton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                enregistrerBoutonActionPerformed(evt);
            }
        });
        getContentPane().add(enregistrerBouton, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 380, 341, 38));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("ENTREE");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 20, -1, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("Numero de l'entree");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(69, 72, -1, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Numero dumedicament");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 150, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Stock introduite");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 220, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Date de l'entree");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 290, -1, -1));
        getContentPane().add(dateEntree, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 310, 343, 38));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/entree.png"))); // NOI18N
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 0, -1, -1));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/back.png"))); // NOI18N
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 490, 450));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void nMedocActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nMedocActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nMedocActionPerformed

    private void enregistrerBoutonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_enregistrerBoutonActionPerformed
        try {
            
            logique();
            
            
            String id = nEntree.getText();
            String numMedoc = nMedoc.getText();
            String noStock = stockEntree.getText();
            java.util.Date dateE = dateEntree.getDate();

            int nombreStock = Integer.parseInt(noStock);
            
            java.sql.Date sqlDate = new java.sql.Date(dateE.getTime());

            pst = con.prepareStatement("UPDATE entree SET numMedoc = ?, stockEntree = ?, dateEntree = ? WHERE numentree = ?");
            pst.setString(1,numMedoc);
            pst.setInt(2,nombreStock);
            pst.setDate(3, (java.sql.Date) sqlDate);
            pst.setString(4,id);

            int k = pst.executeUpdate();
            

            if (k==1){
                accueilPage.FetchEntree();
                accueilPage.FetchMedicament();
                accueilPage.Rupturestock();
                JOptionPane.showMessageDialog(this,"Modification enregistree avec succes");
                nEntree.setText("");
                nMedoc.setText("");
                stockEntree.setText("");
                dateEntree.setDate(null);
            }else{
                JOptionPane.showMessageDialog(this,"Erreur de l'ajout");
            }
        } catch (SQLException ex) {
            Logger.getLogger(Entree.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_enregistrerBoutonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UpdateEntree.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UpdateEntree.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UpdateEntree.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UpdateEntree.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                 String[] rowData = {};
                
                UpdateEntree dialog = new UpdateEntree(new javax.swing.JFrame(), true, rowData);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                        
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.toedter.calendar.JDateChooser dateEntree;
    private javax.swing.JButton enregistrerBouton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JTextField nEntree;
    private javax.swing.JTextField nMedoc;
    private javax.swing.JTextField stockEntree;
    // End of variables declaration//GEN-END:variables
}
